# Dompet Aan — PWA
Aplikasi dompet + trading journal. Jalankan:
```
npm i
npm run dev
```
Buka http://localhost:3000 lalu **Add to Home Screen** di HP.
